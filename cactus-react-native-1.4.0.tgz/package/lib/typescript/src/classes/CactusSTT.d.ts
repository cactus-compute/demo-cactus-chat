import type { CactusSTTDownloadParams, CactusSTTTranscribeParams, CactusSTTTranscribeResult, CactusSTTParams, CactusSTTAudioEmbedParams, CactusSTTAudioEmbedResult } from '../types/CactusSTT';
import type { CactusSTTModel } from '../types/CactusSTTModel';
export declare class CactusSTT {
    private readonly cactus;
    private readonly model;
    private readonly contextSize;
    private isDownloading;
    private isInitialized;
    private isGenerating;
    private static readonly defaultModel;
    private static readonly defaultContextSize;
    private static readonly defaultPrompt;
    private static readonly defaultTranscribeOptions;
    private static readonly defaultEmbedBufferSize;
    constructor({ model, contextSize }?: CactusSTTParams);
    download({ onProgress, }?: CactusSTTDownloadParams): Promise<void>;
    init(): Promise<void>;
    transcribe({ audio, prompt, options, onToken, }: CactusSTTTranscribeParams): Promise<CactusSTTTranscribeResult>;
    audioEmbed({ audioPath, }: CactusSTTAudioEmbedParams): Promise<CactusSTTAudioEmbedResult>;
    stop(): Promise<void>;
    reset(): Promise<void>;
    destroy(): Promise<void>;
    getModels(): Promise<CactusSTTModel[]>;
}
//# sourceMappingURL=CactusSTT.d.ts.map