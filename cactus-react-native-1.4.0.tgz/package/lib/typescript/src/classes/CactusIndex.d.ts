import type { CactusIndexAddParams, CactusIndexGetParams, CactusIndexGetResult, CactusIndexQueryParams, CactusIndexQueryResult, CactusIndexDeleteParams } from '../types/CactusIndex';
export declare class CactusIndex {
    private readonly cactusIndex;
    private readonly name;
    private readonly embeddingDim;
    constructor(name: string, embeddingDim: number);
    init(): Promise<void>;
    add({ ids, documents, embeddings, metadatas, }: CactusIndexAddParams): Promise<void>;
    delete({ ids }: CactusIndexDeleteParams): Promise<void>;
    get({ ids }: CactusIndexGetParams): Promise<CactusIndexGetResult>;
    query({ embeddings, options, }: CactusIndexQueryParams): Promise<CactusIndexQueryResult>;
    compact(): Promise<void>;
    destroy(): Promise<void>;
}
//# sourceMappingURL=CactusIndex.d.ts.map