import type { CactusLMDownloadParams, CactusLMCompleteParams, CactusLMCompleteResult, CactusLMTokenizeParams, CactusLMTokenizeResult, CactusLMScoreWindowParams, CactusLMScoreWindowResult, CactusLMEmbedParams, CactusLMEmbedResult, CactusLMImageEmbedParams, CactusLMImageEmbedResult, CactusLMParams } from '../types/CactusLM';
import type { CactusModel } from '../types/CactusModel';
export declare class CactusLM {
    private readonly cactus;
    private readonly model;
    private readonly contextSize;
    private readonly corpusDir?;
    private isDownloading;
    private isInitialized;
    private isGenerating;
    private static readonly defaultModel;
    private static readonly defaultContextSize;
    private static readonly defaultCompleteOptions;
    private static readonly defaultCompleteMode;
    private static readonly defaultEmbedBufferSize;
    constructor({ model, contextSize, corpusDir }?: CactusLMParams);
    download({ onProgress, }?: CactusLMDownloadParams): Promise<void>;
    init(): Promise<void>;
    complete({ messages, options, tools, onToken, mode, }: CactusLMCompleteParams): Promise<CactusLMCompleteResult>;
    tokenize({ text, }: CactusLMTokenizeParams): Promise<CactusLMTokenizeResult>;
    scoreWindow({ tokens, start, end, context, }: CactusLMScoreWindowParams): Promise<CactusLMScoreWindowResult>;
    embed({ text, normalize, }: CactusLMEmbedParams): Promise<CactusLMEmbedResult>;
    imageEmbed({ imagePath, }: CactusLMImageEmbedParams): Promise<CactusLMImageEmbedResult>;
    stop(): Promise<void>;
    reset(): Promise<void>;
    destroy(): Promise<void>;
    getModels(): Promise<CactusModel[]>;
}
//# sourceMappingURL=CactusLM.d.ts.map