import type { DeviceInfo } from '../specs/CactusDeviceInfo.nitro';
import type { LogRecord } from '../telemetry/Telemetry';
import type { CactusModel } from '../types/CactusModel';
import type { CactusSTTModel } from '../types/CactusSTTModel';
export declare class Database {
    private static readonly url;
    private static readonly key;
    static sendLogRecords(records: LogRecord[]): Promise<void>;
    static registerDevice({ deviceData, deviceId, }: {
        deviceData?: DeviceInfo;
        deviceId?: string;
    }): Promise<string>;
    static getModel(slug: string): Promise<CactusModel>;
    static getSTTModel(slug: string): Promise<CactusSTTModel>;
    static getModels(): Promise<CactusModel[]>;
    static getSTTModels(): Promise<CactusSTTModel[]>;
}
//# sourceMappingURL=Database.d.ts.map