import type { CactusLMCompleteResult, Message, CompleteOptions, Tool } from '../types/CactusLM';
export declare class RemoteLM {
    private static readonly completionsUrl;
    private static readonly defaultModel;
    static complete(messages: Message[], options?: CompleteOptions, tools?: {
        type: 'function';
        function: Tool;
    }[], callback?: (token: string) => void): Promise<CactusLMCompleteResult>;
    private static getMimeType;
    private static transformMessages;
    private static streamXHR;
    private static nonStreamFetch;
}
//# sourceMappingURL=RemoteLM.d.ts.map