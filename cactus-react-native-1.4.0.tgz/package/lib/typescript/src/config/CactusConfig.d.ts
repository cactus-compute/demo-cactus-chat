export declare class CactusConfig {
    static telemetryToken?: string;
    static isTelemetryEnabled: boolean;
    static cactusToken?: string;
    static cactusProKey?: string;
}
//# sourceMappingURL=CactusConfig.d.ts.map