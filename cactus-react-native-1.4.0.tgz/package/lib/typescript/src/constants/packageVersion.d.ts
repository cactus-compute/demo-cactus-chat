export declare const packageVersion = "1.4.0";
//# sourceMappingURL=packageVersion.d.ts.map