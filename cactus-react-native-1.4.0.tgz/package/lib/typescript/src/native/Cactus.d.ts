import type { CactusLMCompleteResult, Message, CompleteOptions, Tool } from '../types/CactusLM';
import type { CactusSTTTranscribeResult, TranscribeOptions } from '../types/CactusSTT';
export declare class Cactus {
    private readonly hybridCactus;
    init(modelPath: string, contextSize: number, corpusDir?: string): Promise<void>;
    complete(messages: Message[], responseBufferSize: number, options?: CompleteOptions, tools?: {
        type: 'function';
        function: Tool;
    }[], callback?: (token: string, tokenId: number) => void): Promise<CactusLMCompleteResult>;
    tokenize(text: string): Promise<number[]>;
    scoreWindow(tokens: number[], start: number, end: number, context: number): Promise<number>;
    transcribe(audio: string | number[], prompt: string, responseBufferSize: number, options?: TranscribeOptions, callback?: (token: string, tokenId: number) => void): Promise<CactusSTTTranscribeResult>;
    embed(text: string, embeddingBufferSize: number, normalize: boolean): Promise<number[]>;
    imageEmbed(imagePath: string, embeddingBufferSize: number): Promise<number[]>;
    audioEmbed(audioPath: string, embeddingBufferSize: number): Promise<number[]>;
    reset(): Promise<void>;
    stop(): Promise<void>;
    destroy(): Promise<void>;
}
//# sourceMappingURL=Cactus.d.ts.map