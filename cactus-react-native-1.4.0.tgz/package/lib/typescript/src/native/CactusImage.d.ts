export declare class CactusImage {
    private static readonly hybridCactusImage;
    static base64(path: string): Promise<string>;
    static resize(path: string, height: number, width: number, quality: number): Promise<string>;
}
//# sourceMappingURL=CactusImage.d.ts.map