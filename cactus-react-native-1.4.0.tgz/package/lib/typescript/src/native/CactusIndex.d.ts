import type { CactusIndexGetResult, CactusIndexQueryResult, IndexQueryOptions } from '../types/CactusIndex';
export declare class CactusIndex {
    private readonly hybridCactusIndex;
    init(indexPath: string, embeddingDim: number): Promise<void>;
    add(ids: number[], documents: string[], embeddings: number[][], metadatas?: string[]): Promise<void>;
    delete(ids: number[]): Promise<void>;
    get(ids: number[]): Promise<CactusIndexGetResult>;
    query(embeddings: number[][], options?: IndexQueryOptions): Promise<CactusIndexQueryResult>;
    compact(): Promise<void>;
    destroy(): Promise<void>;
}
//# sourceMappingURL=CactusIndex.d.ts.map