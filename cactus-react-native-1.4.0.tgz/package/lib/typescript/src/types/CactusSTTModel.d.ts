export interface CactusSTTModel {
    slug: string;
    sizeMb: number;
    downloadUrl: string;
    createdAt: Date;
    isDownloaded: boolean;
}
//# sourceMappingURL=CactusSTTModel.d.ts.map