import type { CactusLMParams, CactusLMCompleteParams, CactusLMCompleteResult, CactusLMTokenizeParams, CactusLMTokenizeResult, CactusLMScoreWindowParams, CactusLMScoreWindowResult, CactusLMEmbedParams, CactusLMEmbedResult, CactusLMImageEmbedParams, CactusLMImageEmbedResult, CactusLMDownloadParams } from '../types/CactusLM';
import type { CactusModel } from '../types/CactusModel';
export declare const useCactusLM: ({ model, contextSize, corpusDir, }?: CactusLMParams) => {
    completion: string;
    isGenerating: boolean;
    isInitializing: boolean;
    isDownloaded: boolean;
    isDownloading: boolean;
    downloadProgress: number;
    error: string | null;
    download: ({ onProgress }?: CactusLMDownloadParams) => Promise<void>;
    init: () => Promise<void>;
    complete: ({ messages, options, tools, onToken, mode, }: CactusLMCompleteParams) => Promise<CactusLMCompleteResult>;
    tokenize: ({ text, }: CactusLMTokenizeParams) => Promise<CactusLMTokenizeResult>;
    scoreWindow: ({ tokens, start, end, context, }: CactusLMScoreWindowParams) => Promise<CactusLMScoreWindowResult>;
    embed: ({ text, normalize, }: CactusLMEmbedParams) => Promise<CactusLMEmbedResult>;
    imageEmbed: ({ imagePath, }: CactusLMImageEmbedParams) => Promise<CactusLMImageEmbedResult>;
    reset: () => Promise<void>;
    stop: () => Promise<void>;
    destroy: () => Promise<void>;
    getModels: () => Promise<CactusModel[]>;
};
//# sourceMappingURL=useCactusLM.d.ts.map