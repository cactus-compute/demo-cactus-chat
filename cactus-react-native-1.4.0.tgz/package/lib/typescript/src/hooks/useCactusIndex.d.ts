import type { CactusIndexParams, CactusIndexAddParams, CactusIndexGetParams, CactusIndexGetResult, CactusIndexQueryParams, CactusIndexQueryResult, CactusIndexDeleteParams } from '../types/CactusIndex';
export declare const useCactusIndex: ({ name, embeddingDim }: CactusIndexParams) => {
    isInitializing: boolean;
    isProcessing: boolean;
    error: string | null;
    init: () => Promise<void>;
    add: ({ ids, documents, metadatas, embeddings, }: CactusIndexAddParams) => Promise<void>;
    delete: ({ ids }: CactusIndexDeleteParams) => Promise<void>;
    get: ({ ids }: CactusIndexGetParams) => Promise<CactusIndexGetResult>;
    query: ({ embeddings, options, }: CactusIndexQueryParams) => Promise<CactusIndexQueryResult>;
    compact: () => Promise<void>;
    destroy: () => Promise<void>;
};
//# sourceMappingURL=useCactusIndex.d.ts.map