import type { CactusSTTParams, CactusSTTTranscribeResult, CactusSTTTranscribeParams, CactusSTTDownloadParams, CactusSTTAudioEmbedParams, CactusSTTAudioEmbedResult } from '../types/CactusSTT';
import type { CactusSTTModel } from '../types/CactusSTTModel';
export declare const useCactusSTT: ({ model, contextSize, }?: CactusSTTParams) => {
    transcription: string;
    isGenerating: boolean;
    isInitializing: boolean;
    isDownloaded: boolean;
    isDownloading: boolean;
    downloadProgress: number;
    error: string | null;
    download: ({ onProgress }?: CactusSTTDownloadParams) => Promise<void>;
    init: () => Promise<void>;
    transcribe: ({ audio, prompt, options, onToken, }: CactusSTTTranscribeParams) => Promise<CactusSTTTranscribeResult>;
    audioEmbed: ({ audioPath, }: CactusSTTAudioEmbedParams) => Promise<CactusSTTAudioEmbedResult>;
    reset: () => Promise<void>;
    stop: () => Promise<void>;
    destroy: () => Promise<void>;
    getModels: () => Promise<CactusSTTModel[]>;
};
//# sourceMappingURL=useCactusSTT.d.ts.map